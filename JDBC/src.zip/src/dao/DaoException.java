package dao;

public class DaoException extends Exception {
    public DaoException(Throwable e) {
        super(e);
    }
}
